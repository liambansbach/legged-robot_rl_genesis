"""Package measured results without altering simulation evidence."""
import json
from pathlib import Path
import zipfile
import hashlib

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+"\n", encoding="utf-8")

root = Path(".migration-audit/yaw-source-20261011")
read = lambda p: json.loads((root/p).read_text())
nominal, sensitivity = read("nominal/metrics.json"), read("friction07/metrics.json")
audit, installed = read("trace_audit.json"), read("installed_source.json")
reference = read("reference/yaw_display_result.json")
bundle = Path("ressources/handoffs/go2w_2026-10-09/inference/go2w")
contract = json.loads((bundle/"contract.json").read_text())
initial = read("nominal/initialized.json")

cases = []
for c in nominal["cases"].values():
    windows = c["windows"]
    full = windows["full_hold"]
    cases.append({"yaw_rad_s": c["command_rad_s"], "first_actor_phase": c["first_actor_phase"],
                  "yaw_onset_phase": c["yaw_onset_phase"], "failure": c["failure"],
                  "whole_hold_mean_body_vx_vy_wz": full["mean_body_vx_vy_wz"],
                  "hold_motion": c["hold_motion"], "stop": c["stopping"],
                  "stop_last1s_planar_rms_m_s": windows["stop_last_second"]["planar_rms_m_s"],
                  "stop_last1s_yaw_rms_rad_s": windows["stop_last_second"]["rmse_vx_vy_wz"][2],
                  "late_wheel_target_rad_s": windows["last_second"]["wheel_target_mean_rad_s"],
                  "late_wheel_speed_rad_s": windows["last_second"]["wheel_speed_mean_rad_s"],
                  "late_wheel_tracking_rmse_rad_s": windows["last_second"]["wheel_tracking_rmse_rad_s"],
                  "late_leg_tracking_rmse_rad": windows["last_second"]["leg_tracking_rmse_rad"],
                  "full_hold_leg_clip_fraction": full["leg_action_clipped_fraction"],
                  "late_wheel_load_fraction_gt8N": windows["last_second"]["wheel_load_fraction_gt8N"],
                  "full_hold_min_leg_limit_margin_rad": min(full["joint_limit_min_margin_rad"]),
                  "nonwheel_ground_contact_steps": c["nonwheel_contact_steps"]})

variant_rows=[]
for name,c in sensitivity["cases"].items():
    old=nominal["cases"][name]["windows"]["last_second"]["mean_body_vx_vy_wz"][2]
    new=c["windows"]["last_second"]["mean_body_vx_vy_wz"][2]
    variant_rows.append({"yaw_rad_s":c["command_rad_s"],"late_nominal_rad_s":old,
                         "late_friction07_rad_s":new,"signed_change_rad_s":new-old,
                         "failure":c["failure"],"stopping":c["stopping"]})

receipts=[read(f"launch{i:02d}_receipt.json") for i in (1,2)]
result={
    "date":"2026-10-11", "section":"W only: Windows Genesis source comparison",
    "status":"Completed; nominal settings retained. Cross-engine contact/actuation response implicated; exact solver cause not isolated.",
    "identities":{
        "root":str(Path.cwd()),"branch":"testing","reviewed_and_execution_base_head":"e9d40a35d3362e8a9535816d9ae1e829c6bc1c46",
        "remote":"git@github.com:liambansbach/legged-robot_rl_genesis.git","upstream":"origin/testing","initial_worktree":"clean","initial_divergence_after_fetch":[0,0],
        "navigation_reviewed_head":"da89a687c4122cfe19d8ccdca080d6ce4c44d7cd",
        "navigation_remote_head_read_only":"56bb62530d7ea2dcd03418567bcb2d28d3328429",
        "navigation_yaw_result_blob_unchanged_at_newer_head":"5322d5d1b623bf7e66bef5e5f55b5ace14ac8529",
        "training_source":"5b70e79de134107ef08be4bf92cc912bd334ce8b",
        "environment_control_observation_phase_source_identical_at_execution_base":installed["source_training_runtime_diff"]=="",
        "actor_sha256":nominal["actor_sha256"],"urdf_sha256":nominal["urdf_sha256"],
        "bundle_file_sha256":{name:sha256(bundle/name) for name in ("policy.pt","contract.json","config.yaml","provenance.json")},
        "actor":"NEW58-input frozen TorchScript, CK1999 refinement lineage; embedded normalizer, deterministic mean; no native checkpoint inference/re-export",
        "navigation_framework_pin":"c647d3915c4c8b2dc13efecf73865d0450f9c42c",
        "code_at_native_execution":nominal["source"],
        "final_git_revision":"Use the commit containing this result; local and remote SHA are reported by the completion message (avoids a self-referential commit hash).",
    },
    "runtime":nominal["runtime"], "actual_imports":installed["imports"],"gpu_driver":installed["driver"],
    "runtime_difference":"Laptop Torch2.9.1+cu130/RTX5060 versus original desktop Torch2.9.0+cu130/RTX4070Ti. Genesis1.4.1 remains installed. Environment not recreated or updated.",
    "effective_settings":{
        "physics_dt_s":.005,"actor_dt_s":.02,"decimation":4,"seed":1,"robots":1,"display":"Headless; no renderer changes or GUI throughput measurements",
        "joint_order":contract["joint_order"],"wheel_order":nominal["wheel_order"],
        "leg_joint_order":[contract["joint_order"][i] for i in contract["leg_action_indices"]],
        "armature_kg_m2":.01,"leg_kp_kd":[40,1],"wheel_kp_kd":[0,1],"passive_stiffness_damping_frictionloss":[0,0,0],
        "action_scales_hip_thigh_calf_wheel":[.30,.35,.40,18],"action_bound":1,"wheel_target_limit_rad_s":20,
        "effort_limits_Nm":contract["effort_limits"],"joint_velocity_limits_rad_s":contract["joint_velocity_limits"],
        "phase_period_s":.8,"first_actor_phase":.025,"yaw_onset_phase_expected":.525,"leg_reference_hip_thigh_calf_rad":[0,.7,-1.4],
        "spawn_z_m":initial["config"]["init_state"]["pos"][2],
        "noise_DR_push_delay_resampling_outer_feedback":False,
        "wheel_geometry_mu":1.,"nominal_wheel_ratio":1.,"ground_geometry_mu":.1,"ground_ratio":1.,"effective_wheel_ground_mu":1.,
        "genesis_solver_options":initial["solver_options"],
        "genesis_solver_names":"approximate_implicitfast; Newton constraints; pyramidal friction; convex contact; contact patch disabled; 50 iterations /50 line-search iterations; .01s constraint time constant; rolling/torsional disabled",
        "physx_recorded_solver_iterations_position_velocity":[8,2],
        "readback":"All initialized/reset property JSONs in evidence. Armature/gains/passive terms/effort limits checked against contract; mass/COM/inertia unchanged. Sensitivity changes only four wheel ratios; all geometry coefficients and ground/nonwheel ratios unchanged.",
    },
    "protocol":"Each fresh explicit nominal reset has exactly one zero-action20ms tick, followed by2s zero/4s requested yaw/2s zero; phase/history continue through command changes. Additional make_env initialization zero tick is excluded and counted in budget.",
    "sample_alignment":"Genesis paired pre-action/post-step50Hz; PhysX reset rows removed and every fourth200Hz post-step row selected. First1s hold=actor100:150, last1s=250:300, full4s=100:300. Old PhysX published200Hz means retained separately; small sampling differences are not tuning.",
    "yaw_comparison":read("matched_comparison.json"),
    "physx_published_200Hz_fresh_curve":reference["tracking"]["fresh_reset_curve"],
    "source_support_actuation_stopping":cases,
    "contact_sensitivity":{
        "source_fresh_reset_cases":variant_rows,
        "receiving_paired_nominal_late_rad_s":reference["tracking"]["paired_nominal_late_wz"],
        "receiving_paired_friction07_late_rad_s":reference["tracking"]["variants"]["friction07_paired"]["late_yaw_rad_s"],
        "scope":"Genesis fresh +/- .8 sensitivities; receiving paired sequence .6,-.6,.8,-.8 has retained conditioning. Compare each engine's within-protocol change, not an exactly matched friction07 cross-engine trial. No calibration/default promotion.",
    },
    "contacts":audit["contact_windows"],
    "findings":[
        "Source yaw undershoot is not reproduced: fresh +/- .6/.8 late means differ from request by at most .00815rad/s. Matched PhysX50Hz late means undershoot by .26285..29624rad/s. Source full4s RMSE .03746..04761 versus target .27761..30220rad/s.",
        "The NEW Actor/normalizer, phase, history, frames, nominal armature, SI gains, passive properties and action scales are consistent. Recorded source CPU/GPU export actions agree within3.58e-7 on90 shared inputs. A command scale or wrong-policy explanation is not supported.",
        "PhysX wheel speeds are comparable to, sometimes higher than, Genesis although body yaw is much smaller. Both engines have leg compliance and some leg clipping; there is no wheel action clipping. Matching gain numbers does not prove equivalent actuator integration.",
        "Effective wheel friction1->.7 changes source late yaw by -.00025/-.00508rad/s for+/- .8, whereas receiving paired changes are about+.09979/-.09998rad/s. Alongside different contact formulations, this favors cross-engine contact/actuation response over missing learned yaw tracking. It does not identify one unique solver parameter.",
        "Genesis stopping is not perfect: +.8 reverses heading by .06972rad after release; +1 reverses by .07563rad and does not meet the stated .25s sustained settling criterion within2s. Source hold tracking success is not whole-envelope qualification.",
    ],
    "contact_implementation":{
        "installed_source_hashes":installed["files"],"combination":installed["combination"],"force_semantics":installed["pyramidal_force"],"actuation":installed["actuation"],
        "physx_reference":"https://nvidia-omniverse.github.io/PhysX/physx/5.4.1/docs/RigidBodyDynamics.html#friction-and-restitution",
        "interpretation":"Equal scalar max-combined friction is not equal contact dynamics: Genesis measured pyramidal constraints/no contact patch versus PhysX's documented contact-patch friction formulation. Exact target friction-type runtime readback is absent; do not infer a unique solver cause from defaults.",
    },
    "remaining_gaps":["One seed and one robot, no statistical robustness claim.","PhysX .3 and +/-1 retained conditioning differs; no exact eight-case claim.","No matched contact-point velocity/slip and no PhysX tangential contact force trace; null is unavailable, never zero.","No single actuation/contact/geometry-response mechanism isolated; no physical floor calibration or hardware validation.","Positive1rad/s source stop remains unsettled by the bounded criterion; no longer rollout authorized/performed."],
    "checks":{"focused_tests_passed":14,"trace_audit_cases":10,"cpu_gpu_shared_inputs":90,"cpu_gpu_actor_max_abs_error":audit["max_cpu_gpu_actor_error"],
              "receiving_shared_inputs":36,"cpu_export_vs_receiving_action_max_abs":max(c["physx_matched_50Hz"]["cpu_export_vs_receiving_issued_action_max_abs_9_inputs"] for c in read("matched_comparison.json") if c["physx_matched_50Hz"]),
              "actor_and_normalizer_unchanged":nominal["actor_state_unchanged"] and sensitivity["actor_state_unchanged"],
              "stale_test_fixture":"Existing CPU FK test mixed the legacy URDF/old expected heights with current joint reference. Updated to measured URDF and .4277416561558192m; initial failure and passing rerun retained.",
              "git_diff_check":"passed","native_exit_codes":[r["exit_code"] for r in receipts]},
    "budget":{"native_simulator_launches":2,"bounded_rollouts":10,"nominal_rollouts":8,"sensitivity_rollouts":2,
              "actor_rollout_seconds_each":8,"reset_inclusive_rollout_seconds_each":8.02,"total_actor_sim_seconds":80,
              "extra_factory_initialization_ticks":2,"total_sim_seconds_including_all_reset_ticks":80.24,
              "cumulative_native_process_wall_seconds":sum(r["wall_seconds"] for r in receipts),"process_receipts":receipts,
              "ceilings":{"launches":6,"rollouts":10,"seconds_per_rollout":15,"native_process_wall_seconds":1800},
              "scope":"Full wall receipts include Python imports/build/recording/shutdown. Offline unit tests/import probes/Git/evidence analysis are not simulator launches; no scene created by those commands."},
    "one_recommended_next_action":"Run one bounded receiving-side replay of the recorded Genesis +/- .8 named joint targets with fixed nominal physics and matched reset, recording actual joint response and tangential ground-contact forces. This removes Actor feedback as a confound before considering any contact/actuator change; stop on first failure. No training proposed or executed.",
    "owner_command":"conda run -n genesis-gpu python -X utf8 -m robot_gym.scripts.evaluate --task go2w --eval_mode source_yaw --headless --diagnostic_trace --output evaluation/source_yaw_owner",
    "preservation":"Policy/normalizer/canonical assets/training settings/historical evidence retained. No training, export, Linux execution, navigation integration, hardware work, package edits or remote writes to navigation repository.",
}

zip_path=Path("docs/go2w_source_yaw_2026-10-11_evidence.zip")
with zipfile.ZipFile(zip_path,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    files=[]
    for folder in ("nominal","friction07"):
        files.extend((root/folder).glob("*.json")); files.extend((root/folder).glob("*.npz"))
    files.extend(root/name for name in ("analyze.py","build_result.py","installed_source.json","trace_audit.json","matched_comparison.json","launch01.log","launch02.log","launch01_receipt.json","launch02_receipt.json","test_diagnostics.log","test_diagnostics_after.log"))
    files.append(root/"reference/yaw_display_result.json")
    for p in files:
        z.write(p, p.relative_to(root).as_posix())
result["evidence_archive"]={"path":zip_path.as_posix(),"bytes":zip_path.stat().st_size,"sha256":sha256(zip_path),
                            "contents":"Ten paired50Hz traces and four1s200Hz contact windows; initialized/reset readbacks; exact configs; process receipts; analysis/audit; immutable receiving summary. Receiving raw archive retained locally/read-only, not duplicated.",
                            "receiving_raw_archive":reference["evidence_archive"],
                            "trace_storage":"Optional bounded NPZ files; no persistent recorder in ordinary play"}
write_json("docs/go2w_source_yaw_2026-10-11.json",result)
print(json.dumps({"archive_bytes":zip_path.stat().st_size,"native_wall_seconds":result["budget"]["cumulative_native_process_wall_seconds"],"source_sensitivity":variant_rows},indent=2))
