"""Offline source/receiving comparison. Run from the Genesis repository root."""
import hashlib
import importlib
import importlib.metadata
import io
import json
from pathlib import Path
import subprocess
import tarfile

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch

from robot_gym.envs.go2w.source_yaw import BUNDLE, YAWS
from robot_gym.utils.diagnostics import write_json, sha256, heading_wxyz

ROOT = Path(".migration-audit/yaw-source-20261011")
nominal = json.loads((ROOT / "nominal/metrics.json").read_text())
variant = json.loads((ROOT / "friction07/metrics.json").read_text())
reference = json.loads((ROOT / "reference/yaw_display_result.json").read_text())
contract = json.loads((BUNDLE / "contract.json").read_text())
archive = tarfile.open(ROOT / "reference/yaw_display_evidence_download.tar.gz")
assert sha256(ROOT / "reference/yaw_display_evidence_download.tar.gz") == reference["evidence_archive"]["sha256"]
wi, li = contract["wheel_action_indices"], contract["leg_action_indices"]

def body(q, v):
    xyz = -q[:, :3]
    c = 2 * np.cross(xyz, v)
    return v + q[:, 3:] * c + np.cross(xyz, c)

def target_trace(yaw):
    folder = f"nominal_curve/{yaw:g}"
    d = np.load(io.BytesIO(archive.extractfile(folder + "/physics.npz").read()))
    meta = json.load(archive.extractfile(folder + "/physics.json"))
    r = d["physics"]
    reset = r[r[:, 2] == 1]
    r = r[r[:, 2] == 0]
    assert len(reset) == 4 and len(r) == 1600
    selected = r[3::4]
    np.testing.assert_allclose(selected[:, 1], np.arange(1, 401)*.02, atol=1e-6)
    assert meta["joint_names"] == contract["joint_order"]
    return selected, meta, d["policy"], r

def target_metrics(yaw):
    r, meta, a, all_r = target_trace(yaw)
    indices = [0, 99, 100, 101, 149, 250, 299, 300, 399]
    with torch.no_grad():
        exported = actor(torch.from_numpy(a[indices,3:61].copy())).clamp(-1,1).numpy()
    actor_error = float(np.abs(exported-a[indices,61:77]).max())
    assert actor_error < 5e-5
    q = r[:, 8:12]
    velocity = np.c_[body(q, r[:, 12:15])[:, :2], body(q, r[:, 15:18])[:, 2]]
    late = slice(250, 300)
    force = r[:, 66:117].reshape(-1, len(meta["body_names"]), 3)
    wheel_ids = [meta["body_names"].index(n) for n in meta["wheel_names"]]
    return {
        "cpu_export_vs_receiving_issued_action_max_abs_9_inputs": actor_error,
        "first_second_rad_s": float(velocity[100:150, 2].mean()),
        "last_second_rad_s": float(velocity[late, 2].mean()),
        "full4s_rmse_rad_s": float(np.sqrt(np.mean((velocity[100:300, 2]-yaw)**2))),
        "late_body_xy_mean_m_s": velocity[late, :2].mean(0),
        "late_wheel_target_rad_s": r[late, 140:156][:, wi].mean(0),
        "late_wheel_speed_rad_s": r[late, 34:50][:, wi].mean(0),
        "late_wheel_tracking_rmse_rad_s": np.sqrt(np.mean((r[late, 140:156][:, wi]-r[late, 34:50][:, wi])**2, 0)),
        "late_leg_tracking_rmse_rad": np.sqrt(np.mean((r[late, 124:140][:, li]-r[late, 18:34][:, li])**2, 0)),
        "full_hold_leg_clipped_fraction": (np.abs(a[100:300, 61:77][:, li]) >= 1.).mean(0),
        "late_load_fraction_gt8N": (force[late][:, wheel_ids, 2] > 8).mean(0),
        "late_clearance_gt1mm_fraction": (r[late, 156:160] > .001).mean(0),
        "tangential_contact_force": None,
        "contact_point_slip": None,
        "quat_heading_change_rad": float(np.unwrap(np.arctan2(2*(q[:,3]*q[:,2]+q[:,0]*q[:,1]), 1-2*(q[:,1]**2+q[:,2]**2)))[299] - np.unwrap(np.arctan2(2*(q[:,3]*q[:,2]+q[:,0]*q[:,1]), 1-2*(q[:,1]**2+q[:,2]**2)))[99]),
    }

comparison, audits, contacts = [], {}, {}
actor = torch.jit.load(str(BUNDLE / "policy.pt"), map_location="cpu").eval()
sample_error = 0.
for mode, report in (("nominal", nominal), ("friction07", variant)):
    for name, case in report["cases"].items():
        d = np.load(ROOT / mode / (name + ".npz"))
        assert len(d["pre_time_s"]) == 400 and case["failure"] is None
        for key in d.files:
            if not key.startswith("physics_contact_"):
                assert np.isfinite(d[key]).all(), key
        for key in ("base_pos", "base_quat", "base_lin_vel", "base_ang_vel", "dof_pos", "dof_vel"):
            np.testing.assert_array_equal(d["pre_" + key][1:], d["post_" + key][:-1])
        np.testing.assert_array_equal(d["pre_previous_issued_action"][1:], d["post_actions"][:-1])
        np.testing.assert_array_equal(d["pre_observation"][:,40:56], d["pre_previous_issued_action"])
        np.testing.assert_array_equal(d["post_applied_actions"], d["post_actions"])
        circular_error = (d["pre_phase"] - (.025 + np.arange(400)*.025) + .5) % 1 - .5
        np.testing.assert_allclose(circular_error, 0., atol=6e-6, rtol=0)
        np.testing.assert_allclose(d["pre_phase"][[0,100]], [.025,.525], atol=2e-6, rtol=0)
        cmd = np.zeros((400,3), dtype=np.float32); cmd[100:300,2] = case["command_rad_s"]
        np.testing.assert_array_equal(d["post_commands"], cmd)
        scales = np.array([contract["observation_scales"]["lin_vel"]]*2 +
                          [contract["observation_scales"]["ang_vel"]], dtype=np.float32)
        np.testing.assert_array_equal(d["pre_observation"][:,9:12], cmd*scales)
        expected_clock = np.c_[np.sin(2*np.pi*d["pre_phase"]), np.cos(2*np.pi*d["pre_phase"])]
        expected_clock[:100] = expected_clock[300:] = 0
        np.testing.assert_allclose(d["pre_observation"][:,-2:], expected_clock, atol=1e-6)
        indices = [0, 99, 100, 101, 149, 250, 299, 300, 399]
        with torch.no_grad():
            pred = actor(torch.from_numpy(d["pre_observation"][indices].copy())).numpy()
        err = float(np.max(np.abs(pred-d["post_raw_actions"][indices])))
        assert err < 5e-5
        sample_error = max(sample_error, err)
        audits[mode+"/"+name] = {"paired_pre_post_exact": True, "command_and_action_history_exact": True,
                                "phase_checked": True, "actor_cpu_gpu_max_abs": err,
                                "raw_actor_observation_max_abs": float(np.abs(d["pre_observation"]).max()),
                                "no_failure_or_auto_reset": True}
        if "physics_time_s" in d:
            np.testing.assert_allclose(d["physics_time_s"], 2+np.arange(1,201)*.005)
            valid = d["physics_contact_valid_mask"]
            # Each ground pair has one ground link(0); force on the robot is the other side.
            a, b = d["physics_contact_link_a"], d["physics_contact_link_b"]
            assert np.all((a[valid] == 0) | (b[valid] == 0))
            f = np.where((a != 0)[...,None], d["physics_contact_force_a"], d["physics_contact_force_b"])
            f = np.where(valid[...,None], f, 0.)
            pos = d["physics_contact_position"]
            radius = pos-d["physics_base_pos"][:,None,:]
            normal = d["physics_contact_normal"]
            tang = f - np.sum(f*normal,axis=-1,keepdims=True)*normal
            summed = f.sum(1)
            moment = np.cross(radius, f).sum(1)
            contacts[mode+"/"+name] = {
                "post_time_window_s": [2.005,3.0], "samples": 200,
                "available": ["position_world", "normal_world", "force_a_world", "force_b_world", "link_a", "link_b", "valid_mask"],
                "mean_total_ground_force_world_N": summed.mean(0),
                "rms_total_horizontal_force_N": float(np.sqrt(np.mean(np.sum(summed[:,:2]**2,axis=1)))),
                "mean_sum_contact_tangential_norm_N": float(np.linalg.norm(tang,axis=2).sum(1).mean()),
                "rms_ground_yaw_moment_about_authored_base_Nm": float(np.sqrt(np.mean(moment[:,2]**2))),
                "peak_nonwheel_normal_force_N": float(d["physics_nonwheel_normal_force"].max()),
                "contact_point_slip": None,
                "interpretation": "Full solver-reported contact forces and positions; force components available. No contact-point velocity/material tire slip measured; no equivalent PhysX shear trace exists."
            }
        if mode == "nominal":
            yaw = case["command_rad_s"]
            target = target_metrics(yaw) if abs(yaw) in (.6,.8) else None
            item = {"requested_rad_s": yaw,
                    "genesis_first1s_rad_s": case["windows"]["first_second"]["mean_body_vx_vy_wz"][2],
                    "genesis_last1s_rad_s": case["windows"]["last_second"]["mean_body_vx_vy_wz"][2],
                    "genesis_full4s_rmse_rad_s": case["windows"]["full_hold"]["rmse_vx_vy_wz"][2],
                    "physx_matched_50Hz": target,
                    "conditioning": "fresh reset/2s zero/4s yaw/2s stop; matched schedule, phase, Actor and sample cadence" if target else "PhysX retained conditioning differs; descriptive comparison only"}
            if target:
                item["source_minus_target_late_rad_s"] = item["genesis_last1s_rad_s"] - target["last_second_rad_s"]
            elif abs(yaw) == .3:
                i = 0 if yaw > 0 else 1
                item["physx_unmatched_last1s_rad_s"] = reference["tracking"]["reused_yaw_0_3"]["last_second"][i]
            else:
                segments = reference["tracking"]["extension_and_translations"]["segments"]
                item["physx_unmatched_last1s_rad_s"] = next(s["late_body_vx_vy_wz"][2] for s in segments if s["command"] == [0,0,yaw])
            comparison.append(item)

write_json(ROOT/"trace_audit.json", {"cases": audits, "contact_windows": contacts, "max_cpu_gpu_actor_error": sample_error})
write_json(ROOT/"matched_comparison.json", comparison)
print(json.dumps(comparison, default=lambda x: x.tolist(), indent=2))

fig, ax = plt.subplots(1, 3, figsize=(14, 4.4), layout="constrained")
fig.suptitle("Frozen Go2-W Actor: Genesis tracks yaw; PhysX undershoots", fontsize=15)
xs = np.array([c["requested_rad_s"] for c in comparison]); ys = np.array([c["genesis_last1s_rad_s"] for c in comparison])
ax[0].plot([-1,1],[-1,1],color="0.6",ls="--",label="Requested")
ax[0].scatter(xs,ys,color="#087f8c",label="Genesis nominal",zorder=3)
matched=[c for c in comparison if c["physx_matched_50Hz"]]
ax[0].scatter([c["requested_rad_s"] for c in matched],[c["physx_matched_50Hz"]["last_second_rad_s"] for c in matched],color="#d45d31",marker="s",label="PhysX matched")
unmatched=[c for c in comparison if not c["physx_matched_50Hz"]]
ax[0].scatter([c["requested_rad_s"] for c in unmatched],[c["physx_unmatched_last1s_rad_s"] for c in unmatched],facecolors="none",edgecolors="#d45d31",marker="s",label="PhysX other conditioning")
ax[0].set(xlabel="Requested yaw (rad/s)",ylabel="Last-second mean yaw (rad/s)",title="Response curve (50 Hz matched cases)")
ax[0].legend(fontsize=8,loc="upper left")
for j, yaw in enumerate((.8,-.8),1):
    d=np.load(ROOT/"nominal"/f"yaw_{yaw:+.1f}.npz")
    r,_,_,_=target_trace(yaw)
    ax[j].plot(d["post_time_s"],d["post_base_ang_vel"][:,2],color="#087f8c",lw=1,label="Genesis nominal")
    ax[j].plot(r[:,1],body(r[:,8:12],r[:,15:18])[:,2],color="#d45d31",lw=1,label="PhysX nominal")
    ax[j].plot(d["pre_time_s"],d["post_commands"][:,2],color="0.45",ls="--",lw=1,label="Requested")
    ax[j].set(xlabel="Simulation time after reset tick (s)",ylabel="Body yaw rate (rad/s)",title=f"Fresh reset, requested {yaw:+.1f} rad/s")
    ax[j].legend(fontsize=8)
for a in ax:
    a.grid(alpha=.2)
    a.spines[["top","right"]].set_visible(False)
fig.savefig("docs/go2w_source_yaw_2026-10-11.png", dpi=170)

pkg=Path(gs_file := importlib.import_module("genesis").__file__).parent
paths = ["engine/entities/rigid_entity/rigid_entity.py", "engine/solvers/rigid/collider/contact.py",
         "engine/solvers/rigid/constraint/solver.py", "engine/solvers/rigid/abd/accessor.py",
         "engine/solvers/rigid/abd/forward_dynamics.py"]
write_json(ROOT/"installed_source.json", {
    "imports": {name: importlib.import_module(name).__file__ for name in ("genesis","torch","numpy","rsl_rl","yaml","robot_gym")},
    "files": {str(pkg/p): sha256(pkg/p) for p in paths},
    "driver": subprocess.check_output(["nvidia-smi","--query-gpu=name,driver_version,memory.total","--format=csv,noheader"],text=True,stdin=subprocess.DEVNULL,stderr=subprocess.PIPE).strip(),
    "source_training_runtime_diff": subprocess.check_output(["git","diff","5b70e79de134107ef08be4bf92cc912bd334ce8b","e9d40a35d3362e8a9535816d9ae1e829c6bc1c46","--","robot_gym/envs/base/legged_robot.py","robot_gym/envs/go2w/go2w_env.py","robot_gym/envs/go2w/go2w_config.py","robot_gym/envs/go2w/phase.py"],text=True,stdin=subprocess.DEVNULL,stderr=subprocess.PIPE),
    "combination": "contact.py: max(mu_a*ratio_a,mu_b*ratio_b,.01); sol_params averaged then time constant floored at2*substep_dt",
    "pyramidal_force": "constraint/solver.py reconstructs contact force from four normal+tangent friction-pyramid constraint directions; exported force includes tangential components",
    "actuation": "approximate_implicitfast forward dynamics includes implicit PD mass terms; get_dofs_control_force recomputes current clipped PD, not integration impulse",
})
